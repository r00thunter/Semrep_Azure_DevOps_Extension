/**
 * Semgrep Azure DevOps Extension - Task Input UI
 * Handles form interactions, validation, and state management
 */

(function() {
    'use strict';

    /**
     * Main UI Controller Class
     */
    class SemgrepTaskUI {
        constructor() {
            this.form = document.getElementById('semgrep-config-form');
            this.sections = {};
            this.validators = {};
            this.tooltip = document.getElementById('tooltip');
            this.init();
        }

        /**
         * Initialize the UI
         */
        init() {
            if (!this.form) {
                console.error('Form not found');
                return;
            }

            this.setupSections();
            this.setupEventListeners();
            this.setupValidation();
            this.setupConditionalFields();
            this.setupTooltips();
            this.setupCharacterCounters();
            this.setupFieldDependencies();
            this.setupInputHelpers();
            this.setupAccessibility();
            this.setupPerformanceOptimizations();
            this.setupIntegration();
            this.loadSavedState();
            
            // Initialize conditional fields visibility
            this.updateConditionalFields();
            
            // Show welcome message for first-time users
            this.showWelcomeMessage();
        }

        /**
         * Setup collapsible sections
         */
        setupSections() {
            const sectionHeaders = document.querySelectorAll('.section-header');
            
            sectionHeaders.forEach(header => {
                const section = header.closest('.config-section');
                const content = section.querySelector('.section-content');
                const isExpanded = section.getAttribute('data-expanded') === 'true';
                
                if (isExpanded) {
                    content.classList.add('expanded');
                }
                
                this.sections[section.getAttribute('data-section')] = {
                    element: section,
                    header: header,
                    content: content,
                    expanded: isExpanded
                };
                
                header.addEventListener('click', (e) => {
                    if (e.target.closest('.toggle-section')) {
                        this.toggleSection(section.getAttribute('data-section'));
                    }
                });
            });
        }

        /**
         * Toggle section expand/collapse
         */
        toggleSection(sectionName) {
            const section = this.sections[sectionName];
            if (!section) return;

            section.expanded = !section.expanded;
            section.element.setAttribute('data-expanded', section.expanded);
            
            if (section.expanded) {
                section.content.classList.add('expanded');
            } else {
                section.content.classList.remove('expanded');
            }
        }

        /**
         * Setup event listeners
         */
        setupEventListeners() {
            // Form submission
            this.form.addEventListener('submit', (e) => {
                e.preventDefault();
                if (this.validateForm()) {
                    this.saveConfiguration();
                }
            });

            // Preview button
            const previewBtn = document.getElementById('preview-btn');
            if (previewBtn) {
                previewBtn.addEventListener('click', () => {
                    this.previewConfiguration();
                });
            }

            // Reset button
            const resetBtn = document.getElementById('reset-btn');
            if (resetBtn) {
                resetBtn.addEventListener('click', () => {
                    if (confirm('Are you sure you want to reset all fields to their default values?')) {
                        this.resetToDefaults();
                    }
                });
            }

            // Export button
            const exportBtn = document.getElementById('export-btn');
            if (exportBtn) {
                exportBtn.addEventListener('click', () => {
                    this.exportConfiguration();
                });
            }

            // Import button
            const importBtn = document.getElementById('import-btn');
            if (importBtn) {
                importBtn.addEventListener('click', () => {
                    this.importConfiguration();
                });
            }

            // Keyboard shortcuts
            document.addEventListener('keydown', (e) => {
                // Ctrl/Cmd + S to save
                if ((e.ctrlKey || e.metaKey) && e.key === 's') {
                    e.preventDefault();
                    if (this.validateForm()) {
                        this.saveConfiguration();
                    }
                }
                // Ctrl/Cmd + P to preview
                if ((e.ctrlKey || e.metaKey) && e.key === 'p') {
                    e.preventDefault();
                    this.previewConfiguration();
                }
                // Ctrl/Cmd + E to export
                if ((e.ctrlKey || e.metaKey) && e.key === 'e') {
                    e.preventDefault();
                    this.exportConfiguration();
                }
            });

            // Password toggle
            const togglePassword = document.querySelector('.toggle-password');
            if (togglePassword) {
                togglePassword.addEventListener('click', () => {
                    const input = document.getElementById('semgrepAppToken');
                    if (input.type === 'password') {
                        input.type = 'text';
                        togglePassword.textContent = '🙈';
                    } else {
                        input.type = 'password';
                        togglePassword.textContent = '👁️';
                    }
                });
            }

            // Real-time validation on input change
            const inputs = this.form.querySelectorAll('input, select, textarea');
            inputs.forEach(input => {
                input.addEventListener('blur', () => {
                    this.validateField(input);
                });
                
                input.addEventListener('input', () => {
                    // Clear error on input
                    const formGroup = input.closest('.form-group');
                    if (formGroup && formGroup.classList.contains('has-error')) {
                        this.clearFieldError(input);
                    }
                    // Real-time validation for certain fields
                    if (input.name === 'deploymentId' || input.name === 'semgrepAppToken') {
                        // Debounce validation for performance
                        clearTimeout(input._validationTimeout);
                        input._validationTimeout = setTimeout(() => {
                            this.validateField(input);
                        }, 500);
                    }
                });

                // Add focus highlight
                input.addEventListener('focus', () => {
                    input.closest('.form-group')?.classList.add('is-focused');
                });

                input.addEventListener('blur', () => {
                    input.closest('.form-group')?.classList.remove('is-focused');
                });
            });

            // Conditional field triggers
            const conditionalTriggers = this.form.querySelectorAll('[data-show]');
            conditionalTriggers.forEach(trigger => {
                const field = this.form.querySelector(`[name="${trigger.getAttribute('data-show').split(' == ')[0]}"]`);
                if (field) {
                    field.addEventListener('change', () => {
                        this.updateConditionalFields();
                    });
                }
            });

            // Ticket types checkbox handling
            const ticketTypeCheckboxes = this.form.querySelectorAll('input[name="ticketTypes"]');
            ticketTypeCheckboxes.forEach(checkbox => {
                checkbox.addEventListener('change', () => {
                    this.handleTicketTypesChange();
                    this.updateConditionalFields();
                });
            });
        }

        /**
         * Handle ticket types checkbox changes
         */
        handleTicketTypesChange() {
            const allCheckbox = this.form.querySelector('input[name="ticketTypes"][value="All"]');
            const otherCheckboxes = this.form.querySelectorAll('input[name="ticketTypes"]:not([value="All"])');
            
            if (allCheckbox && allCheckbox.checked) {
                // If "All" is checked, uncheck others
                otherCheckboxes.forEach(cb => cb.checked = false);
            } else {
                // If any other is checked, uncheck "All"
                const anyChecked = Array.from(otherCheckboxes).some(cb => cb.checked);
                if (anyChecked) {
                    allCheckbox.checked = false;
                }
            }
        }

        /**
         * Setup form validation
         */
        setupValidation() {
            this.validators = {
                semgrepAppToken: (value) => {
                    if (!value || value.trim() === '') {
                        return 'Semgrep App Token is required';
                    }
                    if (value.length < 10) {
                        return 'Token appears to be too short';
                    }
                    // Check for common token patterns
                    if (!/^[a-zA-Z0-9_-]+$/.test(value.trim())) {
                        return 'Token contains invalid characters';
                    }
                    return null;
                },
                deploymentId: (value) => {
                    if (!value || value.trim() === '') {
                        return 'Deployment ID is required';
                    }
                    if (!/^\d+$/.test(value.trim())) {
                        return 'Deployment ID must be numeric';
                    }
                    if (value.trim().length > 10) {
                        return 'Deployment ID appears to be too long';
                    }
                    return null;
                },
                baselineRef: (value) => {
                    if (!value || value.trim() === '') {
                        return 'Baseline Reference is required for PR Scan';
                    }
                    // Validate git reference format
                    if (!/^[\w\/\.-]+$/.test(value.trim())) {
                        return 'Invalid git reference format';
                    }
                    return null;
                },
                semgrepOrg: (value) => {
                    if (value && value.trim() !== '') {
                        if (!/^[a-zA-Z0-9_-]+$/.test(value.trim())) {
                            return 'Organization name contains invalid characters';
                        }
                        if (value.trim().length < 2) {
                            return 'Organization name is too short';
                        }
                    }
                    return null;
                },
                fixPRBranchPrefix: (value) => {
                    if (value && value.trim() !== '') {
                        if (!/^[\w\/\.-]+$/.test(value.trim())) {
                            return 'Branch prefix contains invalid characters';
                        }
                        if (!value.endsWith('/') && !value.endsWith('-')) {
                            return 'Branch prefix should end with "/" or "-"';
                        }
                    }
                    return null;
                },
                iterationListCsvUrl: (value) => {
                    if (value && value.trim() !== '') {
                        try {
                            new URL(value.trim());
                        } catch (e) {
                            return 'Invalid URL format';
                        }
                    }
                    return null;
                },
                azureDevPathCsvUrl: (value) => {
                    if (value && value.trim() !== '') {
                        try {
                            new URL(value.trim());
                        } catch (e) {
                            return 'Invalid URL format';
                        }
                    }
                    return null;
                },
                defaultIterationPath: (value) => {
                    if (value && value.trim() !== '') {
                        if (!/^[^<>:"|?*\\]+$/.test(value.trim())) {
                            return 'Iteration path contains invalid characters';
                        }
                    }
                    return null;
                },
                licenseWhitelistOverride: (value) => {
                    if (value && value.trim() !== '') {
                        const licenses = value.split(/[,\n]/).map(l => l.trim()).filter(l => l);
                        if (licenses.length === 0) {
                            return 'Please enter at least one license';
                        }
                        // Validate license names (basic check)
                        const invalidLicenses = licenses.filter(l => !/^[a-zA-Z0-9\s\._-]+$/.test(l));
                        if (invalidLicenses.length > 0) {
                            return `Invalid license names: ${invalidLicenses.join(', ')}`;
                        }
                    }
                    return null;
                },
                customRuleFilters: (value) => {
                    if (value && value.trim() !== '') {
                        const rules = value.split(/[,\n]/).map(r => r.trim()).filter(r => r);
                        if (rules.length === 0) {
                            return 'Please enter at least one rule';
                        }
                        // Validate rule names (basic check)
                        const invalidRules = rules.filter(r => !/^[-]?[a-zA-Z0-9\._-]+$/.test(r));
                        if (invalidRules.length > 0) {
                            return `Invalid rule names: ${invalidRules.join(', ')}`;
                        }
                    }
                    return null;
                }
            };
        }

        /**
         * Validate a single field
         */
        validateField(field) {
            const fieldName = field.name || field.id;
            const validator = this.validators[fieldName];
            
            if (!validator) {
                // Still check if required field is empty
                if (field.hasAttribute('required') && !field.value.trim()) {
                    const formGroup = field.closest('.form-group');
                    formGroup.classList.add('has-error');
                    const errorElement = formGroup.querySelector('.error-message');
                    if (errorElement) {
                        errorElement.textContent = 'This field is required';
                    }
                    return false;
                }
                return true;
            }

            const value = field.value;
            const error = validator(value);
            const formGroup = field.closest('.form-group');
            const errorElement = formGroup.querySelector('.error-message');

            if (error) {
                formGroup.classList.add('has-error');
                formGroup.classList.remove('has-success');
                if (errorElement) {
                    errorElement.textContent = error;
                }
                return false;
            } else {
                this.clearFieldError(field);
                // Add success indicator for validated fields
                if (value && value.trim() !== '') {
                    formGroup.classList.add('has-success');
                }
                return true;
            }
        }

        /**
         * Clear field error
         */
        clearFieldError(field) {
            const formGroup = field.closest('.form-group');
            formGroup.classList.remove('has-error');
            const errorElement = formGroup.querySelector('.error-message');
            if (errorElement) {
                errorElement.textContent = '';
            }
        }

        /**
         * Add character counter for textareas
         */
        setupCharacterCounters() {
            const textareas = this.form.querySelectorAll('textarea');
            textareas.forEach(textarea => {
                const maxLength = textarea.getAttribute('maxlength');
                if (!maxLength) return;

                const formGroup = textarea.closest('.form-group');
                const counter = document.createElement('span');
                counter.className = 'character-counter';
                counter.textContent = `0/${maxLength} characters`;
                formGroup.appendChild(counter);

                const updateCounter = () => {
                    const length = textarea.value.length;
                    counter.textContent = `${length}/${maxLength} characters`;
                    if (length > maxLength * 0.9) {
                        counter.classList.add('warning');
                    } else {
                        counter.classList.remove('warning');
                    }
                };

                textarea.addEventListener('input', updateCounter);
                updateCounter();
            });
        }

        /**
         * Setup field dependencies and auto-updates
         */
        setupFieldDependencies() {
            // Auto-fill deployment ID if empty
            const deploymentIdField = this.form.querySelector('[name="deploymentId"]');
            if (deploymentIdField && !deploymentIdField.value) {
                deploymentIdField.value = '15145';
            }

            // Auto-expand sections with errors
            this.form.addEventListener('submit', () => {
                const errorFields = this.form.querySelectorAll('.has-error');
                errorFields.forEach(field => {
                    const section = field.closest('.config-section');
                    if (section) {
                        const sectionName = section.getAttribute('data-section');
                        if (sectionName && !this.sections[sectionName].expanded) {
                            this.toggleSection(sectionName);
                        }
                    }
                });
            });
        }

        /**
         * Setup input formatting and helpers
         */
        setupInputHelpers() {
            // URL validation helper
            const urlInputs = this.form.querySelectorAll('input[type="url"]');
            urlInputs.forEach(input => {
                input.addEventListener('blur', () => {
                    const value = input.value.trim();
                    if (value && !value.startsWith('http://') && !value.startsWith('https://')) {
                        if (confirm('URL should start with http:// or https://. Would you like to add https://?')) {
                            input.value = 'https://' + value;
                            this.validateField(input);
                        }
                    }
                });
            });

            // License whitelist formatting
            const licenseTextarea = this.form.querySelector('[name="licenseWhitelistOverride"]');
            if (licenseTextarea) {
                licenseTextarea.addEventListener('blur', () => {
                    // Normalize license list (remove duplicates, trim)
                    const value = licenseTextarea.value;
                    if (value) {
                        const licenses = value.split(/[,\n]/)
                            .map(l => l.trim())
                            .filter(l => l)
                            .filter((v, i, a) => a.indexOf(v) === i); // Remove duplicates
                        licenseTextarea.value = licenses.join(',\n');
                    }
                });
            }

            // Custom rule filters formatting
            const ruleFiltersTextarea = this.form.querySelector('[name="customRuleFilters"]');
            if (ruleFiltersTextarea) {
                ruleFiltersTextarea.addEventListener('blur', () => {
                    // Normalize rule list
                    const value = ruleFiltersTextarea.value;
                    if (value) {
                        const rules = value.split(/[,\n]/)
                            .map(r => r.trim())
                            .filter(r => r)
                            .filter((v, i, a) => a.indexOf(v) === i); // Remove duplicates
                        ruleFiltersTextarea.value = rules.join(',\n');
                    }
                });
            }
        }

        /**
         * Validate entire form
         */
        validateForm() {
            let isValid = true;
            const requiredFields = this.form.querySelectorAll('[required]');

            requiredFields.forEach(field => {
                if (!this.validateField(field)) {
                    isValid = false;
                }
            });

            // Validate scan type specific fields
            const scanType = this.form.querySelector('[name="scanType"]').value;
            if (scanType === 'PR Scan') {
                const baselineRef = this.form.querySelector('[name="baselineRef"]');
                if (baselineRef && !this.validateField(baselineRef)) {
                    isValid = false;
                }
            }

            return isValid;
        }

        /**
         * Setup conditional field visibility
         */
        setupConditionalFields() {
            // This will be called on field changes
        }

        /**
         * Enhanced conditional fields visibility with advanced logic
         */
        updateConditionalFields() {
            const conditionalGroups = this.form.querySelectorAll('.form-group.conditional');
            
            conditionalGroups.forEach(group => {
                const condition = group.getAttribute('data-show');
                if (!condition) return;

                const shouldShow = this.evaluateCondition(condition);

                if (shouldShow) {
                    group.classList.add('show');
                    group.setAttribute('aria-hidden', 'false');
                    // Enable fields when shown
                    group.querySelectorAll('input, select, textarea').forEach(field => {
                        field.disabled = false;
                        field.setAttribute('aria-disabled', 'false');
                    });
                } else {
                    group.classList.remove('show');
                    group.setAttribute('aria-hidden', 'true');
                    // Disable fields when hidden (but don't clear values)
                    group.querySelectorAll('input, select, textarea').forEach(field => {
                        if (!field.hasAttribute('data-keep-enabled')) {
                            field.disabled = true;
                            field.setAttribute('aria-disabled', 'true');
                        }
                    });
                }
            });

            // Handle nested sections visibility based on ticket types
            const enableTicketCreation = this.form.querySelector('[name="enableTicketCreation"]')?.checked || false;
            const ticketTypes = Array.from(this.form.querySelectorAll('input[name="ticketTypes"]:checked'))
                .map(cb => cb.value);

            const sastSection = this.sections['sast'];
            const scaSection = this.sections['sca'];
            const licenseSection = this.sections['license'];

            if (sastSection) {
                const shouldShow = enableTicketCreation && (ticketTypes.includes('SAST') || ticketTypes.includes('All'));
                sastSection.element.style.display = shouldShow ? 'block' : 'none';
                sastSection.element.setAttribute('aria-hidden', shouldShow ? 'false' : 'true');
            }

            if (scaSection) {
                const shouldShow = enableTicketCreation && (ticketTypes.includes('SCA') || ticketTypes.includes('All'));
                scaSection.element.style.display = shouldShow ? 'block' : 'none';
                scaSection.element.setAttribute('aria-hidden', shouldShow ? 'false' : 'true');
            }

            if (licenseSection) {
                const shouldShow = enableTicketCreation && (ticketTypes.includes('License') || ticketTypes.includes('All'));
                licenseSection.element.style.display = shouldShow ? 'block' : 'none';
                licenseSection.element.setAttribute('aria-hidden', shouldShow ? 'false' : 'true');
            }
        }

        /**
         * Evaluate condition string with advanced logic
         */
        evaluateCondition(condition) {
            // Handle complex conditions with && and ||
            if (condition.includes(' && ')) {
                return condition.split(' && ').every(part => this.evaluateCondition(part.trim()));
            }
            
            if (condition.includes(' || ')) {
                return condition.split(' || ').some(part => this.evaluateCondition(part.trim()));
            }

            // Handle simple conditions
            if (condition.includes(' == ')) {
                const [fieldName, value] = condition.split(' == ').map(s => s.trim().replace(/'/g, ''));
                const field = this.form.querySelector(`[name="${fieldName}"], [id="${fieldName}"]`);
                
                if (field) {
                    if (field.type === 'checkbox') {
                        return field.checked === (value === 'true');
                    } else {
                        return field.value === value;
                    }
                }
            } else if (condition.includes(' == true')) {
                const fieldName = condition.split(' == true')[0].trim();
                const field = this.form.querySelector(`[name="${fieldName}"], [id="${fieldName}"]`);
                if (field) {
                    return field.checked === true || field.value === 'true';
                }
            } else if (condition.includes(' != ')) {
                const [fieldName, value] = condition.split(' != ').map(s => s.trim().replace(/'/g, ''));
                const field = this.form.querySelector(`[name="${fieldName}"], [id="${fieldName}"]`);
                
                if (field) {
                    if (field.type === 'checkbox') {
                        return field.checked !== (value === 'true');
                    } else {
                        return field.value !== value;
                    }
                }
            }

            return false;
        }

        /**
         * Setup tooltips with enhanced functionality
         */
        setupTooltips() {
            const helpIcons = this.form.querySelectorAll('.help-icon');
            
            helpIcons.forEach(icon => {
                const helpText = icon.getAttribute('data-help');
                if (!helpText) return;

                // Add ARIA attributes for accessibility
                icon.setAttribute('role', 'button');
                icon.setAttribute('aria-label', 'Show help information');
                icon.setAttribute('tabindex', '0');

                // Mouse events
                icon.addEventListener('mouseenter', (e) => {
                    this.showTooltip(e.target, helpText);
                });

                icon.addEventListener('mouseleave', () => {
                    this.hideTooltip();
                });

                icon.addEventListener('mousemove', (e) => {
                    this.updateTooltipPosition(e);
                });

                // Keyboard events for accessibility
                icon.addEventListener('focus', (e) => {
                    this.showTooltip(e.target, helpText);
                });

                icon.addEventListener('blur', () => {
                    this.hideTooltip();
                });

                icon.addEventListener('keydown', (e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        this.toggleTooltip(e.target, helpText);
                    }
                });
            });
        }

        /**
         * Toggle tooltip on/off
         */
        toggleTooltip(element, text) {
            if (this.tooltip.classList.contains('show')) {
                this.hideTooltip();
            } else {
                this.showTooltip(element, text);
            }
        }

        /**
         * Show tooltip
         */
        showTooltip(element, text) {
            this.tooltip.textContent = text;
            this.tooltip.classList.add('show');
            this.updateTooltipPosition({ target: element });
        }

        /**
         * Hide tooltip
         */
        hideTooltip() {
            this.tooltip.classList.remove('show');
        }

        /**
         * Update tooltip position with smart positioning
         */
        updateTooltipPosition(e) {
            if (!this.tooltip.classList.contains('show')) return;

            const rect = e.target.getBoundingClientRect();
            const tooltipRect = this.tooltip.getBoundingClientRect();
            const viewportWidth = window.innerWidth;
            const viewportHeight = window.innerHeight;

            let left = rect.left;
            let top = rect.bottom + 5;

            // Adjust if tooltip would go off screen
            if (left + tooltipRect.width > viewportWidth) {
                left = viewportWidth - tooltipRect.width - 10;
            }

            if (top + tooltipRect.height > viewportHeight) {
                top = rect.top - tooltipRect.height - 5;
            }

            // Ensure tooltip stays on screen
            if (left < 10) left = 10;
            if (top < 10) top = 10;

            this.tooltip.style.left = left + 'px';
            this.tooltip.style.top = top + 'px';
        }

        /**
         * Get form data as object
         */
        getFormData() {
            const formData = new FormData(this.form);
            const data = {};

            // Handle checkboxes (multi-select)
            const checkboxGroups = {};
            this.form.querySelectorAll('input[type="checkbox"]').forEach(checkbox => {
                const name = checkbox.name;
                if (!checkboxGroups[name]) {
                    checkboxGroups[name] = [];
                }
                if (checkbox.checked) {
                    checkboxGroups[name].push(checkbox.value);
                }
            });

            // Convert FormData to object
            for (const [key, value] of formData.entries()) {
                if (checkboxGroups[key]) {
                    data[key] = checkboxGroups[key].join(',');
                } else {
                    data[key] = value;
                }
            }

            // Handle boolean fields
            this.form.querySelectorAll('input[type="checkbox"]').forEach(checkbox => {
                if (!checkboxGroups[checkbox.name]) {
                    data[checkbox.name] = checkbox.checked;
                }
            });

            return data;
        }

        /**
         * Save configuration with loading state
         */
        saveConfiguration() {
            const saveBtn = document.getElementById('save-btn');
            const originalText = saveBtn?.textContent;
            
            // Show loading state
            if (saveBtn) {
                saveBtn.classList.add('loading');
                saveBtn.disabled = true;
            }

            const formData = this.getFormData();
            
            // Simulate async save (in production, this would be actual API call)
            setTimeout(() => {
                // Save to localStorage
                try {
                    localStorage.setItem('semgrep-config', JSON.stringify(formData));
                    this.showNotification('Configuration saved successfully!', 'success');
                    
                    // In Azure DevOps, this would submit to the task
                    console.log('Form data:', formData);
                    
                    // Announce to screen readers
                    if (this.liveRegion) {
                        this.liveRegion.textContent = 'Configuration saved successfully';
                    }
                } catch (e) {
                    console.error('Failed to save configuration:', e);
                    this.showNotification('Failed to save configuration', 'error');
                } finally {
                    // Remove loading state
                    if (saveBtn) {
                        saveBtn.classList.remove('loading');
                        saveBtn.disabled = false;
                        if (originalText) {
                            saveBtn.textContent = originalText;
                        }
                    }
                }
            }, 500);
        }

        /**
         * Load saved state
         */
        loadSavedState() {
            try {
                const saved = localStorage.getItem('semgrep-config');
                if (!saved) return;

                const data = JSON.parse(saved);
                
                // Populate form fields
                Object.keys(data).forEach(key => {
                    const field = this.form.querySelector(`[name="${key}"], [id="${key}"]`);
                    if (!field) return;

                    if (field.type === 'checkbox') {
                        if (Array.isArray(data[key])) {
                            field.checked = data[key].includes(field.value);
                        } else {
                            field.checked = data[key] === true || data[key] === field.value;
                        }
                    } else if (field.type === 'radio') {
                        field.checked = field.value === data[key];
                    } else {
                        field.value = data[key];
                    }
                });

                // Update conditional fields after loading
                this.updateConditionalFields();
                
                this.showNotification('Configuration loaded from saved state', 'info');
            } catch (e) {
                console.error('Failed to load saved state:', e);
            }
        }

        /**
         * Reset to defaults
         */
        resetToDefaults() {
            this.form.reset();
            
            // Reset checkboxes to defaults
            const enableTicketCreation = this.form.querySelector('[name="enableTicketCreation"]');
            if (enableTicketCreation) enableTicketCreation.checked = true;

            const generateSummary = this.form.querySelector('[name="generateSummary"]');
            if (generateSummary) generateSummary.checked = true;

            const enableMetrics = this.form.querySelector('[name="enableMetrics"]');
            if (enableMetrics) enableMetrics.checked = true;

            // Reset ticket types
            const allTicketType = this.form.querySelector('input[name="ticketTypes"][value="All"]');
            if (allTicketType) allTicketType.checked = true;

            // Clear saved state
            localStorage.removeItem('semgrep-config');
            
            // Update conditional fields
            this.updateConditionalFields();
            
            this.showNotification('Configuration reset to defaults', 'info');
        }

        /**
         * Preview configuration
         */
        previewConfiguration() {
            if (!this.validateForm()) {
                this.showNotification('Please fix errors before previewing', 'error');
                // Scroll to first error
                const firstError = this.form.querySelector('.has-error');
                if (firstError) {
                    firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
                return;
            }

            const formData = this.getFormData();
            this.showPreviewModal(formData);
        }

        /**
         * Show preview modal
         */
        showPreviewModal(data) {
            // Create modal overlay
            const overlay = document.createElement('div');
            overlay.className = 'modal-overlay';
            overlay.innerHTML = `
                <div class="modal-container">
                    <div class="modal-header">
                        <h2>Configuration Preview</h2>
                        <button class="modal-close" aria-label="Close">&times;</button>
                    </div>
                    <div class="modal-content">
                        <pre class="config-preview">${JSON.stringify(data, null, 2)}</pre>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" id="copy-config-btn">Copy to Clipboard</button>
                        <button class="btn btn-primary modal-close">Close</button>
                    </div>
                </div>
            `;
            document.body.appendChild(overlay);

            // Close handlers
            const closeModal = () => overlay.remove();
            overlay.querySelectorAll('.modal-close').forEach(btn => {
                btn.addEventListener('click', closeModal);
            });
            overlay.addEventListener('click', (e) => {
                if (e.target === overlay) closeModal();
            });

            // Copy to clipboard
            const copyBtn = overlay.querySelector('#copy-config-btn');
            if (copyBtn) {
                copyBtn.addEventListener('click', () => {
                    navigator.clipboard.writeText(JSON.stringify(data, null, 2))
                        .then(() => {
                            this.showNotification('Configuration copied to clipboard!', 'success');
                        })
                        .catch(() => {
                            this.showNotification('Failed to copy to clipboard', 'error');
                        });
                });
            }

            // Escape key to close
            const escapeHandler = (e) => {
                if (e.key === 'Escape') {
                    closeModal();
                    document.removeEventListener('keydown', escapeHandler);
                }
            };
            document.addEventListener('keydown', escapeHandler);
        }

        /**
         * Export configuration to file
         */
        exportConfiguration() {
            if (!this.validateForm()) {
                this.showNotification('Please fix errors before exporting', 'error');
                return;
            }

            const formData = this.getFormData();
            const dataStr = JSON.stringify(formData, null, 2);
            const dataBlob = new Blob([dataStr], { type: 'application/json' });
            const url = URL.createObjectURL(dataBlob);
            const link = document.createElement('a');
            link.href = url;
            link.download = `semgrep-config-${new Date().toISOString().split('T')[0]}.json`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(url);
            this.showNotification('Configuration exported successfully!', 'success');
        }

        /**
         * Import configuration from file
         */
        importConfiguration() {
            const input = document.createElement('input');
            input.type = 'file';
            input.accept = '.json';
            input.onchange = (e) => {
                const file = e.target.files[0];
                if (!file) return;

                const reader = new FileReader();
                reader.onload = (event) => {
                    try {
                        const data = JSON.parse(event.target.result);
                        this.loadConfiguration(data);
                        this.showNotification('Configuration imported successfully!', 'success');
                    } catch (error) {
                        this.showNotification('Invalid configuration file', 'error');
                    }
                };
                reader.readAsText(file);
            };
            input.click();
        }

        /**
         * Load configuration data into form
         */
        loadConfiguration(data) {
            Object.keys(data).forEach(key => {
                const field = this.form.querySelector(`[name="${key}"], [id="${key}"]`);
                if (!field) return;

                if (field.type === 'checkbox') {
                    if (Array.isArray(data[key])) {
                        field.checked = data[key].includes(field.value);
                    } else if (typeof data[key] === 'boolean') {
                        field.checked = data[key];
                    } else {
                        field.checked = data[key] === field.value;
                    }
                } else if (field.type === 'radio') {
                    field.checked = field.value === data[key];
                } else {
                    field.value = data[key];
                }
            });

            // Update conditional fields
            this.updateConditionalFields();
            
            // Validate imported data
            this.form.querySelectorAll('input, select, textarea').forEach(field => {
                if (field.value) {
                    this.validateField(field);
                }
            });
        }

        /**
         * Setup accessibility features
         */
        setupAccessibility() {
            // Add ARIA labels to all form fields
            this.form.querySelectorAll('input, select, textarea').forEach(field => {
                const label = this.form.querySelector(`label[for="${field.id}"]`);
                if (label && !field.getAttribute('aria-label')) {
                    const labelText = label.textContent.replace(/\*|ℹ️/g, '').trim();
                    field.setAttribute('aria-label', labelText);
                }
                
                // Add aria-required for required fields
                if (field.hasAttribute('required')) {
                    field.setAttribute('aria-required', 'true');
                }

                // Add aria-invalid for error states
                field.addEventListener('blur', () => {
                    const formGroup = field.closest('.form-group');
                    if (formGroup && formGroup.classList.contains('has-error')) {
                        field.setAttribute('aria-invalid', 'true');
                        const errorElement = formGroup.querySelector('.error-message');
                        if (errorElement) {
                            field.setAttribute('aria-describedby', errorElement.id || field.id + '-error');
                        }
                    } else {
                        field.setAttribute('aria-invalid', 'false');
                    }
                });
            });

            // Add ARIA live region for dynamic content
            const liveRegion = document.createElement('div');
            liveRegion.id = 'aria-live-region';
            liveRegion.setAttribute('aria-live', 'polite');
            liveRegion.setAttribute('aria-atomic', 'true');
            liveRegion.className = 'sr-only';
            document.body.appendChild(liveRegion);
            this.liveRegion = liveRegion;

            // Keyboard navigation for sections
            this.form.querySelectorAll('.section-header').forEach(header => {
                header.setAttribute('role', 'button');
                header.setAttribute('tabindex', '0');
                
                header.addEventListener('keydown', (e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        const section = header.closest('.config-section');
                        const sectionName = section.getAttribute('data-section');
                        this.toggleSection(sectionName);
                    }
                });
            });

            // Skip to main content link
            const skipLink = document.createElement('a');
            skipLink.href = '#semgrep-config-form';
            skipLink.className = 'skip-link';
            skipLink.textContent = 'Skip to main content';
            skipLink.addEventListener('click', (e) => {
                e.preventDefault();
                this.form.focus();
                this.form.scrollIntoView({ behavior: 'smooth' });
            });
            document.body.insertBefore(skipLink, document.body.firstChild);
        }

        /**
         * Setup performance optimizations
         */
        setupPerformanceOptimizations() {
            // Debounce conditional field updates
            this.conditionalUpdateTimeout = null;
            const originalUpdate = this.updateConditionalFields.bind(this);
            this.updateConditionalFields = () => {
                clearTimeout(this.conditionalUpdateTimeout);
                this.conditionalUpdateTimeout = setTimeout(originalUpdate, 100);
            };

            // Lazy load tooltips (only create when needed)
            this.tooltipCache = new Map();

            // Use requestAnimationFrame for smooth animations
            this.animationFrame = null;

            // Auto-save form state periodically
            this.setupAutoSave();
        }

        /**
         * Setup auto-save functionality
         */
        setupAutoSave() {
            let saveTimeout;
            const autoSaveInterval = 30000; // 30 seconds

            const autoSave = () => {
                const formData = this.getFormData();
                try {
                    localStorage.setItem('semgrep-config-autosave', JSON.stringify({
                        data: formData,
                        timestamp: Date.now()
                    }));
                } catch (e) {
                    console.warn('Auto-save failed:', e);
                }
            };

            // Auto-save on field changes
            this.form.addEventListener('input', () => {
                clearTimeout(saveTimeout);
                saveTimeout = setTimeout(autoSave, 2000); // Debounce auto-save
            });

            // Periodic auto-save
            setInterval(() => {
                if (document.hasFocus()) {
                    autoSave();
                }
            }, autoSaveInterval);

            // Auto-save on page unload
            window.addEventListener('beforeunload', autoSave);

            // Check for auto-saved data on load
            this.checkAutoSavedData();
        }

        /**
         * Check for auto-saved data and offer to restore
         */
        checkAutoSavedData() {
            try {
                const saved = localStorage.getItem('semgrep-config-autosave');
                if (!saved) return;

                const { data, timestamp } = JSON.parse(saved);
                const age = Date.now() - timestamp;
                const ageMinutes = Math.floor(age / 60000);

                // Only offer restore if data is less than 1 hour old
                if (ageMinutes < 60) {
                    const currentData = this.getFormData();
                    const hasCurrentData = Object.values(currentData).some(v => v && v !== '' && v !== false);

                    if (!hasCurrentData && confirm(`Found auto-saved configuration from ${ageMinutes} minute(s) ago. Would you like to restore it?`)) {
                        this.loadConfiguration(data);
                        this.showNotification('Configuration restored from auto-save', 'success');
                    }
                }
            } catch (e) {
                console.warn('Failed to check auto-saved data:', e);
            }
        }

        /**
         * Setup Azure DevOps integration features
         */
        setupIntegration() {
            // Check if running in Azure DevOps context
            if (typeof VSS !== 'undefined' && VSS.getExtensionContext) {
                // Azure DevOps specific features
                this.isAzureDevOps = true;
                this.setupAzureDevOpsIntegration();
            } else {
                // Standalone mode
                this.isAzureDevOps = false;
            }
        }

        /**
         * Setup Azure DevOps specific integration
         */
        setupAzureDevOpsIntegration() {
            // This would integrate with Azure DevOps APIs
            // For now, we'll just mark it as available
            console.log('Azure DevOps integration available');
        }

        /**
         * Show welcome message for first-time users
         */
        showWelcomeMessage() {
            const hasSeenWelcome = localStorage.getItem('semgrep-ui-welcome-seen');
            if (!hasSeenWelcome) {
                setTimeout(() => {
                    this.showNotification('Welcome! Use keyboard shortcuts: Ctrl+S to save, Ctrl+P to preview', 'info');
                    localStorage.setItem('semgrep-ui-welcome-seen', 'true');
                }, 1000);
            }
        }

        /**
         * Get form data formatted for Azure DevOps task
         */
        getFormDataForAzureDevOps() {
            const formData = this.getFormData();
            
            // Format data according to Azure DevOps task input requirements
            const azureDevOpsData = {};
            
            Object.keys(formData).forEach(key => {
                const value = formData[key];
                
                // Handle multi-select values (convert arrays to comma-separated strings)
                if (Array.isArray(value)) {
                    azureDevOpsData[key] = value.join(',');
                } else if (typeof value === 'boolean') {
                    azureDevOpsData[key] = value.toString();
                } else {
                    azureDevOpsData[key] = value;
                }
            });
            
            return azureDevOpsData;
        }

        /**
         * Show notification with accessibility
         */
        showNotification(message, type = 'info') {
            // Announce to screen readers
            if (this.liveRegion) {
                this.liveRegion.textContent = `${type}: ${message}`;
                setTimeout(() => {
                    this.liveRegion.textContent = '';
                }, 1000);
            }

            // Visual notification
            const colors = {
                success: '#107C10',
                error: '#E81123',
                info: '#0078D4',
                warning: '#FF8C00'
            };

            const icons = {
                success: '✓',
                error: '✗',
                info: 'ℹ',
                warning: '⚠'
            };

            const notification = document.createElement('div');
            notification.setAttribute('role', 'alert');
            notification.setAttribute('aria-live', 'assertive');
            notification.className = 'notification notification-' + type;
            notification.innerHTML = `
                <span class="notification-icon">${icons[type] || icons.info}</span>
                <span class="notification-message">${message}</span>
                <button class="notification-close" aria-label="Close notification">&times;</button>
            `;
            
            document.body.appendChild(notification);

            // Close button handler
            const closeBtn = notification.querySelector('.notification-close');
            closeBtn.addEventListener('click', () => {
                notification.remove();
            });

            // Auto-remove after delay
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.style.animation = 'slideOut 0.3s ease';
                    setTimeout(() => notification.remove(), 300);
                }
            }, 5000);
        }
    }

    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            new SemgrepTaskUI();
        });
    } else {
        new SemgrepTaskUI();
    }

    // Add CSS for notifications
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        @keyframes slideOut {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(100%);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(style);

})();
